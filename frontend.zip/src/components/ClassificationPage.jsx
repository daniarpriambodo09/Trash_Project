// src/components/ClassificationPage.jsx
import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import Navbar from './Navbar';
import styles from '../styles/ClassificationPage.module.css';

export default function ClassificationPage() {
  const [previewUrl, setPreviewUrl] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [result, setResult] = useState(null);
  const fileInputRef = useRef(null);

  const wasteTypes = [
    {
      category: 'Sampah Organik',
      description: 'Sampah organik adalah sampah yang berasal dari makhluk hidup dan dapat terurai secara alami oleh mikroorganisme. Sampah ini sangat cocok untuk dijadikan kompos yang bermanfaat bagi tanah dan tanaman.',
      icon: '🍃',
      badges: ['♻️ Dapat Didaur Ulang', '🌱 Bisa Dijadikan Kompos']
    },
    {
      category: 'Sampah Plastik',
      description: 'Sampah plastik adalah jenis sampah anorganik yang membutuhkan waktu ratusan tahun untuk terurai. Dapat didaur ulang melalui proses khusus untuk mengurangi pencemaran lingkungan.',
      icon: '💧',
      badges: ['♻️ Dapat Didaur Ulang', '⚠️ Sulit Terurai']
    },
    {
      category: 'Sampah Kertas',
      description: 'Sampah kertas dapat didaur ulang menjadi kertas baru. Pastikan kertas dalam kondisi bersih dan kering untuk proses daur ulang yang optimal.',
      icon: '📄',
      badges: ['♻️ Dapat Didaur Ulang', '🌲 Hemat Sumber Daya']
    },
    {
      category: 'Sampah Logam',
      description: 'Sampah logam memiliki nilai ekonomis tinggi dan dapat didaur ulang berkali-kali tanpa kehilangan kualitas. Daur ulang logam menghemat energi dan sumber daya alam.',
      icon: '🔧',
      badges: ['♻️ Dapat Didaur Ulang', '💰 Nilai Ekonomis']
    }
  ];

  const handleFile = (file) => {
    if (!file.type.startsWith('image/')) {
      alert('Mohon upload file gambar (JPG, PNG, JPEG)');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('Ukuran file terlalu besar. Maksimal 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target.result);
      setResult(null);
    };
    reader.readAsDataURL(file);
  };

  const onFileChange = (e) => {
    if (e.target.files?.[0]) handleFile(e.target.files[0]);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const onDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => setIsDragging(false);

  const triggerFileInput = () => fileInputRef.current?.click();

  const classify = () => {
    if (!previewUrl) return;
    setIsUploading(true);
    setTimeout(() => {
      const randomType = wasteTypes[Math.floor(Math.random() * wasteTypes.length)];
      const confidence = `${Math.floor(Math.random() * 8) + 92}%`;
      setResult({ ...randomType, confidence });
      setIsUploading(false);
    }, 2000);
  };

  const reset = () => {
    setPreviewUrl(null);
    setResult(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <Navbar />

      <main className={styles.mainContent}>
        <h2 className={styles.pageTitle}>Klasifikasi Sampah</h2>

        <div className={styles.classificationSection}>
          <div className={styles.uploadContainer}>
            <div
              className={`${styles.uploadArea} ${isDragging ? styles.dragOver : ''}`}
              onClick={triggerFileInput}
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onDrop={onDrop}
            >
              <div className={styles.uploadIcon}>☁️</div>
              <div className={styles.uploadText}>
                <h3>Seret & Letakkan Gambar Disini</h3>
                <p>Atau Pilih File</p>
              </div>
              <button className={styles.fileButton}>PILIH FILE</button>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={onFileChange}
                hidden
              />
            </div>

            <div className={styles.sampleImages}>
              <div className={styles.sampleTitle}>Contoh Jenis Sampah</div>
              <div className={styles.sampleGrid}>
                {[
                  { icon: '💧', label: 'Plastik' },
                  { icon: '🍃', label: 'Organik' },
                  { icon: '💧', label: 'Botol' },
                  { icon: '🍌', label: 'Buah' }
                ].map((item, i) => (
                  <div key={i} className={styles.sampleItem}>
                    <div style={{ fontSize: '2.5em' }}>{item.icon}</div>
                    <p className={styles.sampleLabel}>{item.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {previewUrl && (
  <div className={`${styles.previewSection} ${styles.fadeSlideUp}`}>
              <div className={styles.previewContainer}>
                <div className={styles.imagePreview}>
                  <img src={previewUrl} alt="Preview" />
                </div>
                <div className={styles.previewActions}>
                  {isUploading ? (
                    <div className={`${styles.loading} ${styles.pulse}`} style={{ transform: 'scale(1)' }}>
                      <div className={styles.spinner}></div>
                      <p>Menganalisis gambar...</p>
                    </div>
                  ) : (
                    <div className={styles.actionButtons}>
                      <button className={styles.classifyBtn} onClick={classify}>
                        🔍 Klasifikasi Sekarang
                      </button>
                      <button className={styles.resetBtn} onClick={reset}>
                        🔄 Upload Gambar Baru
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {result && (
  <div className={styles.resultHeader}>
  <div 
    className={styles.resultIcon}
    style={{ animation: 'fadeIn 0.5s ease-out forwards', opacity: 0 }}
  >
    {result.icon}
  </div>
  <div 
    className={styles.resultInfo}
    style={{ 
      animation: 'fadeIn 0.6s ease-out 0.1s forwards',
      opacity: 0 
    }}
  >
    <h2>{result.category}</h2>
    <div 
      className={styles.confidence}
      style={{ 
        animation: 'fadeIn 0.4s ease-out 0.2s forwards', 
        opacity: 0,
        marginTop: '0.5rem'
      }}
    >
      Akurasi: {result.confidence}
    </div>
  </div>
              <div className={styles.resultDescription}>{result.description}</div>
              <div className={styles.resultBadges}>
                {result.badges.map((badge, i) => (
                  <span key={i} className={styles.badge}>{badge}</span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className={styles.historySection}>
          <h3 className={styles.historyTitle}>Riwayat Unggahan Terakhir</h3>
          <div className={styles.historyGrid}>
            {[
              { icon: '🍃', title: 'Sampah Organik', time: '2 jam yang lalu' },
              { icon: '💧', title: 'Sampah Plastik', time: '5 jam yang lalu' },
              { icon: '📄', title: 'Sampah Kertas', time: '1 hari yang lalu' }
            ].map((item, i) => (
              <div key={i} className={styles.historyCard}>
                <svg width="100%" height="180" viewBox="0 0 300 180">
                  <rect width="300" height="180" fill={i === 0 ? '#e8f5e9' : i === 1 ? '#e3f2fd' : '#fff3e0'} />
                  <text x="150" y="100" textAnchor="middle" fontSize="60">{item.icon}</text>
                </svg>
                <div className={styles.historyCardContent}>
                  <h4>{item.title}</h4>
                  <p>{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </>
  );
}